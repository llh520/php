<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>

<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/solution-details.css"/>
<!-- <link rel="stylesheet" href="css/common.css"/> -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript"></script>

</head>
<body>
   <!--页面头部-->
          <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=14 AND  delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
			<header>
			 <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
        <div class="myDiv1"><p>解决方案</p></div>
       <div class="myDiv2"><p style="text-align: right;">您当前所在位置:<a href="index.php">首页</a>><a href="solution.php">解决方案</a></p></div>
    </header>
    <nav>
        <div class="title"><?php echo $row['title']; ?></div>
    </nav>
    <section>
       <div class="time">更新时间:<?php echo $row['keywords']; ?><?php echo $row['description']; ?><?php echo $row['content']; ?></div>   
    </section>
        <?php
		   }
		  ?>
	<!-- start内容 -->
	 <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=14 AND  delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 4,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
      <article>
         <div class="myDiv3"><?php echo $row['description']; ?></div>
      </article>
      <content>
        <div class="myDiv4">
          <p><?php echo $row['content']; ?></P>
          <p style="float:right;margin-top: 5px;">(编辑：<?php echo $row['author']; ?>)</p>
        </div>
        <div class="myDiv5">上一篇：<a href="#">区域卫生计生管理</a>
        <div class="img">
          <?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=23 AND  delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,2");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
            <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"><?php echo $row['title']; ?>
       
            <?php
               }
            ?>
        </div>
        </div>
        <div class="myDiv6">下一篇：已经没有了</div>
        <div class="myDiv7">0条评论</div>

          <form class="myForm" method="post" action="">
              <div class="myDiv8">
                  <textarea rows="10" cols="200" placeholder="说点什么吧...."></textarea>
              </div>
              <div class="myDiv9">不想登录？直接点击发布即可作为游客留言。</div>
              <button type="submit" class="">发布</button>
          </form>
          
    </content>
	   <?php 
	     }
	   ?>
	<!-- end内容 -->
	<!-- start footer -->
     <div class="footer">
      <div class="container">
         <div class="row">
             <div class="col-lg-9 col-md-9 col-xs-9">
                 <div class="footer-logo">
                      <?php
					$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=19 AND  delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,1");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
					?>
					 <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
			 
                 </div>
                 <div class="footer-text">
                    <?php echo $row['content']; ?>
                 </div>
                 <?php
                   }
			      ?> 
             </div>
             <div class="col-lg-3 col-md-3 col-xs-3">
                 <div class="my-code">
                     <?php
					$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=19 AND  delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
					?>
					 <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
			 
                 </div>
                 <div class="name"><?php echo $row['description']; ?></div>
             </div>
	              <?php
	                   }
				      ?> 
         </div> 
      </div>
   </div>
<!-- end footer -->
</body>
</html>