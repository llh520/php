<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/bootstrap.min.css"/>
<link rel="stylesheet" href="css/aboutUs-honnor.css"/>
<link rel="stylesheet" href="css/common.css"/>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript"></script>

</head>
<body>
<!--start 导航栏 -->
    <?php require_once('about-honner-nav.php'); ?>
<!-- end导航栏 -->
<!--start头部-->
	 <header>
	     <?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=3 AND  delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 2,1");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
			 <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
			<?php
			  }
			?>
      <div class="myDiv1"><p style="text-align: left;">荣誉资质</p></div>
      <div class="myDiv2"><p style="text-align: right;">您当前所在位置:<a href="index.html">首页</a>>关于我们>荣誉资质</p></div>
	 </header>
<!--end头部-->
<!--内容标题-->   
      <div class="aboutUs"><p>荣誉资质</p></div>
<!-- start内容 -->
      <aside>
       <div class="container">
          <div class="row">
             <div class="col-lg-3 col-md-3 col-xs-3 ">
	              <?php
				$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=3 AND  delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 1,1");
				while($row = $dosql->GetArray())
				{
					if($row['linkurl'] != '')$gourl = $row['linkurl'];
					else $gourl = 'javascript:;';
				?>
				 <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">

                  <p><?php echo $row['title']; ?></p>
                  <?php
				     }
				    ?>
                 <div class="a-title">
                    <?php
				$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=3 AND  delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
				while($row = $dosql->GetArray())
				{
					if($row['linkurl'] != '')$gourl = $row['linkurl'];
					else $gourl = 'javascript:;';
				?>
				 <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
                      <?php
				         }
				        ?>
                     <ul>
                        <li>公司简介</li> 
                        <li><a href="aboutUs-honnor.php">荣誉资质</a></li>  
                        <li>企业文化</li>  
                        <li>董事长致辞</li>  
                        <li>公司风采</li>  
                        <li>合作伙伴</li>  
                        <li>公司地址</li> 
                     </ul>
               </div> 
             </div>
             <div class="col-lg-9 col-md-9 col-xs-9">
	              <?php
					$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=28 AND  delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
					?>
              <div class="content">
                    <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
              </div>
              <div class="content2">
                 <ul>
                     <li><?php echo $row['content']; ?></li>
                 </ul>
           </div>
	           <?php
	           }
	           ?>
         </div>
        </div>
     </div>
   </aside>
   <!-- start footer -->
     <div class="footer">
      <div class="container">
         <div class="row">
             <div class="col-lg-9 col-md-9 col-xs-9">
                 <div class="footer-logo">
                      <?php
					$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=19 AND  delstate='' AND checkinfo=true ORDER BY orderid ASC LIMIT 0,1");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
					?>
					 <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
			 
                 </div>
                 <div class="footer-text">
                    <?php echo $row['content']; ?>
                 </div>
                 <?php
                   }
			      ?> 
             </div>
             <div class="col-lg-3 col-md-3 col-xs-3">
                 <div class="my-code">
                     <?php
					$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=19 AND  delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,1");
					while($row = $dosql->GetArray())
					{
						if($row['linkurl'] != '')$gourl = $row['linkurl'];
						else $gourl = 'javascript:;';
					?>
					 <img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>">
			 
                 </div>
                 <div class="name"><?php echo $row['description']; ?></div>
             </div>
	              <?php
	                   }
				      ?> 
         </div> 
      </div>
   </div>
<!-- end footer -->
</body>
</html>